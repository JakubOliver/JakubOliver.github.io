const dropZone = document.getElementById("drop-zone");

dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("hover");
});

dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("hover");
});

dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("hover");

    const file = e.dataTransfer.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    fetch("/upload", {
    method: "POST",
    body: formData
    })
    .then(res => res.json())
    .then(data => {
        showImage(data)
    })
    .catch(err => alert("Chyba při nahrávání: " + err))
});

function showImage(data){
  const img = document.getElementById("uploaded-image");
  console.log(data.url)
  img.src = data.url;
  img.style.zIndex = 1;
  document.getElementById("sentButton").style.display = "inline";
  document.getElementById("image-wrapper").appendChild(img);
  document.getElementById("image-zone").style.display = "block";
  document.getElementById("drop-zone").style.display = "none";
}

let currentCorner = null;
const minSize = 20;

document.querySelectorAll('.corner').forEach(corner => {
  corner.addEventListener('mousedown', (e) => {
    e.preventDefault();

    currentCorner = corner.classList[1];
    
    const overlay = document.getElementById('overlay');
    parentRect = overlay.parentElement.getBoundingClientRect();
    const rect = overlay.getBoundingClientRect();

    oldMouseX = e.clientX;
    oldMouseY = e.clientY;

    oldLeft = rect.left;
    oldTop = rect.top;
    oldWidth = parseFloat(getComputedStyle(overlay, null).getPropertyValue('width').replace('px', ''));
    oldHeight = parseFloat(getComputedStyle(overlay, null).getPropertyValue('height').replace('px', ''));

    document.addEventListener('mousemove', resizeOverlay);
    document.addEventListener('mouseup', () => {
      document.removeEventListener('mousemove', resizeOverlay);
      currentCorner = null;
    }, { once: true });
  });
});

function resizeOverlay(e){
  const mouseX = e.clientX;
  const mouseY = e.clientY;

  switch (currentCorner) {
    case 'top-left':
      width = oldWidth - (mouseX - oldMouseX)
      height = oldHeight - (mouseY - oldMouseY)

      if (width > minSize){
        overlay.style.width = width + 'px'
        overlay.style.left = oldLeft + (mouseX - oldMouseX) - parentRect.left + 'px';
      }

      if (height > minSize) {
        overlay.style.height = height + 'px'
        overlay.style.top = oldTop + (mouseY - oldMouseY) - parentRect.top + 'px'
      }
      break;
    case 'top-right':
      width = oldWidth + (mouseX - oldMouseX)
      height = oldHeight - (mouseY - oldMouseY)

      if (width > minSize) {
        overlay.style.width = width + 'px'
      }
      if (height > minSize) {
        overlay.style.height = height + 'px'
        overlay.style.top = oldTop + (mouseY - oldMouseY) - parentRect.top + 'px'
      }
      break;
    case 'bottom-left':
      width = oldWidth - (mouseX - oldMouseX);
      height = oldHeight + (mouseY - oldMouseY);

      if (width > minSize){
        overlay.style.width = width + 'px';
        overlay.style.left = oldLeft + (mouseX - oldMouseX) - parentRect.left + 'px';
        console.log(parentRect.left)
      }

      if (height > minSize){
        overlay.style.height = oldHeight + (mouseY - oldMouseY) + 'px';
      }
      break;
    case 'bottom-right':
      width = oldWidth + (mouseX - oldMouseX);
      height = oldHeight + (mouseY - oldMouseY);

      if (width > minSize) {
        overlay.style.width = width + 'px'
      }
      if (height > minSize) {
        overlay.style.height = height + 'px'
      }
      break;
  }
}

function getOverlayCoordinates(){
  const overlay = document.getElementById("overlay")
  const image = document.getElementById("uploaded-image")

  const overlayRect = overlay.getBoundingClientRect();
  const imageRect = image.getBoundingClientRect();

  const left = overlayRect.left - imageRect.left;
  const right = left + overlayRect.width;
  const top = overlayRect.top - imageRect.top
  const bottom = top + overlayRect.height

  return {
    left: left / imageRect.width * image.naturalWidth,
    top: top / imageRect.height * image.naturalHeight,
    bottom: bottom / imageRect.height * image.naturalHeight,
    right: right / imageRect.width * image.naturalWidth
  }
}

text = "Prázdné"

function sentCoordinates(){
  const coordinates = getOverlayCoordinates();

  fetch('/coordinates', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(coordinates)
  })
  .then(res => res.json())
  .then(data => {
      console.log(data.text)
      text = data.text

      document.getElementById("copyButton").style.display = "inline";
  })
  .catch(err => alert("Chyba při posílání: " + err))
}

function copyIntoClipboard(){
  navigator.clipboard.writeText(text)
        .then(() => console.log("Text zkopírován"))
        .catch(err => alert("Chyba při kopírování: " + err))
}

function scanImage(){
  console.log("Skenování započato.")
  fetch('/scan', {
    method: 'GET',
  })
  .then(res => res.json())
  .then(data => {
      console.log("Skenování dokončeno.")
      showImage(data)
  })
  .catch(err => alert("Chyba při nahrávání: " + err))
}

function getImageFromDirectory(){
  console.log("Načítání ze složky započato.")
  fetch('/directory',{
    method: 'GET',
  })
  .then(res => res.json())
  .then(data => {
    console.log("Načítání dokončeno.")
    showImage(data)
  })
  .catch(err => alert("Chyba při nahrávání: " + err))
}